Employee Orientation v9
=======================

This module developed to  manage employee orientation/training programs.

Installation
============
Just select it from modules list to install, there is no need to extra installations.

Usage
=====
#.In Employee orientation form, when a Orientation Checklist selects the corresponding departments checklist lines fill automatically.
#.The system automatically create employee orientation request when employee orientation is confirmed.
#.Now when responsible person login in system, he/she will find job allocated as Orientation Checklists Requests and finish it.

Credits
=======
Developer: Anusha @ cybrosys
Guidance: Nilmar Shereef @ cybrosys, shereef@cybrosys.in




