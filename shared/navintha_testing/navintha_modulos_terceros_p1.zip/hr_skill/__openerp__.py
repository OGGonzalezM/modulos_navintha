# -*- coding: utf-8 -*-
###############################################################################
#
#    Copyright (C) 2013 Savoir-faire Linux (<http://www.savoirfairelinux.com>).
#    Stella Fredö <stella.fredo@gmail.com> upgrade it to v9
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
###############################################################################

{
    "name": "Skill Management",
    "version": "9.0.1.1.0",
    "category": "Human Resources",
    "license": "AGPL-3",
    "author": "Savoir-faire Linux and Stella Fredö,Odoo Community Association (OCA)",
    "website": "http://www.savoirfairelinux.com",
    "depends": ["hr"],
    'data': [
        "views/hr_skill.xml",
        "views/hr_employee.xml",
        "security/ir.model.access.csv",
    ],
    'installable': True,
}
