# hr_skill
    Copyright (C) 2013 Savoir-faire Linux (<http://www.savoirfairelinux.com>).
    Stella Fredö <stella.fredo@gmail.com> upgrade it to v9

#{
#    "name": "Skill Management",
#    "version": "9.0.1.1.0",
#    "category": "Human Resources",
#    "license": "AGPL-3",
#    "author": "Savoir-faire Linux and Stella Fredö,Odoo Community Association (OCA)",
#    "website": "http://www.savoirfairelinux.com",
#    "depends": ["hr"],
#    'data': [
#        "views/hr_skill.xml",
#        "views/hr_employee.xml",
#        "security/ir.model.access.csv",
#    ],
#    'installable': True,
#}
#
